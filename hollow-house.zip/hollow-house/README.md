# 🕯️ 空屋低語

使用 Python、Streamlit 與 HTML/CSS 製作的繁體中文恐怖文字冒險。
包含分支選擇、生命值、道具背包、逃生與死亡結局。

## 本機執行

需要 Python 3.10 或更新版本。

```sh
pip install -r requirements.txt
streamlit run app.py
```

## 上傳 GitHub

1. 在 GitHub 建立名為 `hollow-house` 的儲存庫。
2. 選擇 **Add file → Upload files**。
3. 將本資料夾中的 `app.py`、`requirements.txt`、`README.md`、`.gitignore` 上傳到儲存庫根目錄。
4. 按 **Commit changes**。

## 線上遊玩

GitHub Pages 無法直接執行 Python/Streamlit。
可使用 Streamlit Community Cloud：https://share.streamlit.io/
連接 GitHub 儲存庫，選擇對應分支，入口檔指定 `app.py`，再部署。

HTML 標題與場景容器，以及 CSS 樣式，寫在 `app.py` 中。
目前插入 HTML 的內容皆為程式內固定文字。
