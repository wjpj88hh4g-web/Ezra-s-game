import streamlit as st

st.set_page_config(page_title="空屋低語", page_icon="🕯️")
st.markdown('''
<style>
.stApp {background:#09090d;color:#ded6ca;}
h1 {color:#c84545 !important;text-align:center;}
.story {background:#15151c;border-left:4px solid #8b2020;padding:24px;
margin:20px 0;border-radius:8px;font-size:20px;line-height:1.8;}
.whisper {color:#9a8a8a;text-align:center;font-style:italic;}
</style>
<h1>🕯️ 空屋低語</h1>
<p class="whisper">這棟房子，記得每一個進來的人。</p>
''', unsafe_allow_html=True)

ROOMS = {
    "entrance": ("大門在你身後猛然關上。樓上傳來腳步聲，但你明明獨自一人。", [
        ("進入書房", "library"), ("走進廚房", "kitchen"), ("走上樓梯", "landing")]),
    "library": ("書桌抽屜裡躺著一把黃銅鑰匙。書架後方，傳來指甲刮擦的聲音。", [
        ("拿起鑰匙", "take_key"), ("返回大廳", "entrance")]),
    "kitchen": ("冰冷的爐台旁，燃著一根蠟燭。上鎖的地下室裡，有人輕聲呼喚你。", [
        ("拿起蠟燭", "take_candle"), ("打開地下室", "open_cellar"), ("返回大廳", "entrance")]),
    "landing": ("走廊盡頭有一面鏡子。鏡中的你，比你早一步露出微笑。", [
        ("觸碰鏡子", "mirror"), ("退回樓下", "entrance")]),
    "cellar": ("燭光照出一條狹窄通道。盡頭的紅門，像心臟一樣跳動。", [
        ("推開紅門", "escape"), ("返回廚房", "kitchen")]),
}


def reset():
    st.session_state.update(room="entrance", health=100, inventory=[], message="")


if "room" not in st.session_state:
    reset()


def act(action):
    s = st.session_state
    s.message = ""
    if action in ("take_key", "take_candle"):
        item = "黃銅鑰匙" if action == "take_key" else "蠟燭"
        if item in s.inventory:
            s.message = "你已經拿過這件物品。"
        else:
            s.inventory.append(item)
            s.message = f"你拿起了{item}。四周突然安靜下來。"
    elif action == "open_cellar":
        if "黃銅鑰匙" not in s.inventory:
            s.message = "門鎖住了。你需要一把鑰匙。"
        elif "蠟燭" not in s.inventory:
            s.message = "裡面太暗了。先找一點光。"
        else:
            s.room = "cellar"
    elif action == "mirror":
        s.health = max(0, s.health - 35)
        s.message = "一隻冰冷的手抓住你。你掙脫了，但失去 35 點生命。"
        if s.health == 0:
            s.room = "dead"
    else:
        s.room = action


with st.sidebar:
    st.header("生存狀態")
    st.progress(st.session_state.health / 100)
    st.write(f"生命：{st.session_state.health}/100")
    st.subheader("背包")
    st.write("、".join(st.session_state.inventory) or "空空如也")
    st.button("重新開始", on_click=reset, use_container_width=True)

if st.session_state.message:
    st.info(st.session_state.message)

room = st.session_state.room
if room == "escape":
    st.success("你推開紅門，跌進黎明的光裡。身後的房子長長吐了一口氣。你逃出來了。")
elif room == "dead":
    st.error("鏡中的你走了出來。而你，永遠留在玻璃後面。遊戲結束。")
else:
    story, choices = ROOMS[room]
    st.markdown(f'<div class="story">{story}</div>', unsafe_allow_html=True)
    for label, action in choices:
        st.button(label, key=f"{room}_{action}", on_click=act,
                  args=(action,), use_container_width=True)
